import os
import re
import json
import base64
import asyncio
import tempfile
import threading
import numpy as np
from pathlib import Path
from typing import List, Dict, Any, Optional, AsyncGenerator

import httpx
import soundfile as sf

try:
    from faster_whisper import WhisperModel
    WHISPER_AVAILABLE = True
except ImportError:
    WHISPER_AVAILABLE = False

try:
    from TTS.api import TTS as CoquiTTS
    COQUI_AVAILABLE = True
except ImportError:
    COQUI_AVAILABLE = False

try:
    from pypdf import PdfReader
    PDF_AVAILABLE = True
except ImportError:
    PDF_AVAILABLE = False


# ── Paths ─────────────────────────────────────────────────────────────────────

BASE_DIR    = Path(__file__).resolve().parent
DATA_DIR    = BASE_DIR / "data"
UPLOADS_DIR = DATA_DIR / "uploads"
DOCUMENTS_FILE  = DATA_DIR / "documents.json"
DOC_CHUNKS_FILE = DATA_DIR / "document_chunks.json"


# ── Constants ─────────────────────────────────────────────────────────────────

OLLAMA_HOST    = "http://127.0.0.1:11434"
CHAT_ENDPOINT  = f"{OLLAMA_HOST}/api/chat"
EMBED_ENDPOINT = f"{OLLAMA_HOST}/api/embeddings"

GENERAL_MODEL = "llama3.2:1b"
CODE_MODEL    = "qwen2.5-coder:1.5b-base"
EMBED_MODEL   = "nomic-embed-text:latest"

CHUNK_SIZE    = 800
CHUNK_OVERLAP = 120
TOP_K_DOCS    = 3
MAX_EMBED_TEXT = 2500

SUPPORTED_TEXT_EXTENSIONS = {
    ".txt", ".md", ".py", ".js", ".ts", ".json", ".html", ".css",
    ".java", ".c", ".cpp", ".sh", ".yml", ".yaml", ".xml", ".sql"
}
SUPPORTED_PDF_EXTENSIONS = {".pdf"}
CODE_EXTENSIONS = {
    ".py", ".js", ".ts", ".json", ".html", ".css", ".java", ".c", ".cpp",
    ".sh", ".xml", ".yml", ".yaml", ".sql"
}

TTS_MODEL_NAME = "tts_models/en/vctk/vits"
TTS_SPEAKER    = "p273"


# ── Storage Init ──────────────────────────────────────────────────────────────

def ensure_storage():
    DATA_DIR.mkdir(exist_ok=True)
    UPLOADS_DIR.mkdir(exist_ok=True)
    for path, default in [(DOCUMENTS_FILE, []), (DOC_CHUNKS_FILE, [])]:
        if not path.exists():
            with open(path, "w", encoding="utf-8") as f:
                json.dump(default, f)

ensure_storage()


# ── JSON Helpers ──────────────────────────────────────────────────────────────

def load_json(path: Path, default):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default


def save_json(path: Path, data):
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False)
    os.replace(tmp, path)


def load_documents():   return load_json(DOCUMENTS_FILE, [])
def save_documents(d):  save_json(DOCUMENTS_FILE, d)
def load_doc_chunks():  return load_json(DOC_CHUNKS_FILE, [])
def save_doc_chunks(d): save_json(DOC_CHUNKS_FILE, d)


# ── Whisper STT ───────────────────────────────────────────────────────────────

_whisper_model: Optional[Any] = None


def get_whisper_model():
    global _whisper_model
    if _whisper_model is None:
        if not WHISPER_AVAILABLE:
            raise RuntimeError("faster-whisper not installed.")
        _whisper_model = WhisperModel("base", device="cpu", compute_type="int8")
    return _whisper_model


def transcribe_audio(audio_bytes: bytes, mime: str = "audio/webm") -> str:
    """
    Transcribe audio bytes from MediaRecorder (webm/opus or fallback).
    faster-whisper accepts any format ffmpeg can decode.
    """
    model = get_whisper_model()

    # Pick extension based on mime so ffmpeg decodes correctly
    if "ogg" in mime:
        ext = ".ogg"
    elif "mp4" in mime or "m4a" in mime:
        ext = ".mp4"
    else:
        ext = ".webm"  # default — covers audio/webm;codecs=opus

    with tempfile.NamedTemporaryFile(suffix=ext, delete=False) as tmp:
        tmp.write(audio_bytes)
        tmp_path = tmp.name

    try:
        segments, _ = model.transcribe(
            tmp_path,
            language="en",
            beam_size=3,
            vad_filter=True,
            vad_parameters={"min_silence_duration_ms": 300}
        )
        return " ".join(seg.text.strip() for seg in segments).strip()
    finally:
        try:
            os.unlink(tmp_path)
        except Exception:
            pass


# ── Coqui TTS ─────────────────────────────────────────────────────────────────

_coqui_tts:  Optional[Any] = None
_coqui_lock = threading.Lock()


def get_coqui_tts():
    global _coqui_tts
    if _coqui_tts is None:
        with _coqui_lock:
            if _coqui_tts is None:
                if not COQUI_AVAILABLE:
                    raise RuntimeError("TTS not installed.")
                _coqui_tts = CoquiTTS(TTS_MODEL_NAME, progress_bar=False)
    return _coqui_tts


def synthesize_speech(text: str) -> bytes:
    text = text.strip()
    if not text:
        return b""
    tts = get_coqui_tts()
    with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
        tmp_path = tmp.name
    try:
        tts.tts_to_file(text=text, speaker=TTS_SPEAKER, file_path=tmp_path)
        with open(tmp_path, "rb") as f:
            return f.read()
    finally:
        try:
            os.unlink(tmp_path)
        except Exception:
            pass


# ── Embedding ─────────────────────────────────────────────────────────────────

def embed_text(text: str) -> List[float]:
    text = text[:MAX_EMBED_TEXT]
    try:
        r = httpx.post(EMBED_ENDPOINT, json={"model": EMBED_MODEL, "prompt": text}, timeout=120)
        r.raise_for_status()
        data = r.json()
        if "embedding" in data:
            return data["embedding"]
    except Exception:
        pass
    r = httpx.post(f"{OLLAMA_HOST}/api/embed", json={"model": EMBED_MODEL, "input": text}, timeout=120)
    r.raise_for_status()
    data = r.json()
    if "embeddings" in data and data["embeddings"]:
        return data["embeddings"][0]
    raise RuntimeError("Embedding failed")


def cosine_similarity(a: List[float], b: List[float]) -> float:
    va = np.array(a, dtype=np.float32)
    vb = np.array(b, dtype=np.float32)
    denom = np.linalg.norm(va) * np.linalg.norm(vb)
    return float(np.dot(va, vb) / denom) if denom > 0 else 0.0


def top_k_similar(query_emb: List[float], items: List[Dict], k: int) -> List[Dict]:
    scored = []
    for item in items:
        emb = item.get("embedding")
        if not emb:
            continue
        obj = dict(item)
        obj["score"] = cosine_similarity(query_emb, emb)
        scored.append(obj)
    scored.sort(key=lambda x: x["score"], reverse=True)
    return scored[:k]


# ── Text Chunking ─────────────────────────────────────────────────────────────

def chunk_text(text: str) -> List[str]:
    text = text.replace("\r\n", "\n").strip()
    if not text:
        return []
    chunks, start, n = [], 0, len(text)
    while start < n:
        end   = min(start + CHUNK_SIZE, n)
        chunk = text[start:end]
        if end < n:
            nb = max(chunk.rfind("\n\n"), chunk.rfind("\n"), chunk.rfind(". "), chunk.rfind(" "))
            if nb > CHUNK_SIZE // 2:
                end   = start + nb
                chunk = text[start:end]
        chunk = chunk.strip()
        if chunk:
            chunks.append(chunk)
        if end >= n:
            break
        start = max(end - CHUNK_OVERLAP, start + 1)
    return chunks


# ── File Processing ───────────────────────────────────────────────────────────

def is_code_file(filename: str) -> bool:
    return Path(filename).suffix.lower() in CODE_EXTENSIONS


def extract_text(file_path: Path, original_name: str) -> str:
    ext = Path(original_name).suffix.lower()
    if ext in SUPPORTED_PDF_EXTENSIONS:
        if not PDF_AVAILABLE:
            raise RuntimeError("pypdf not installed")
        reader = PdfReader(str(file_path))
        return "\n".join(p.extract_text() or "" for p in reader.pages).strip()
    if ext in SUPPORTED_TEXT_EXTENSIONS:
        return file_path.read_text(encoding="utf-8", errors="ignore")
    raise RuntimeError(f"Unsupported file type: {ext}")


def ingest_file(file_path: Path, original_name: str) -> Dict:
    import shutil, uuid
    from datetime import datetime

    text = extract_text(file_path, original_name)
    if not text.strip():
        raise ValueError("No text extracted from file")

    chunks = chunk_text(text)
    if not chunks:
        raise ValueError("No valid chunks from file")

    file_id     = str(uuid.uuid4())
    safe_name   = f"{file_id}_{Path(original_name).name}"
    stored_path = UPLOADS_DIR / safe_name
    shutil.copy2(file_path, stored_path)

    doc_meta = {
        "id":          file_id,
        "filename":    original_name,
        "stored_name": safe_name,
        "is_code":     is_code_file(original_name),
        "uploaded_at": datetime.utcnow().isoformat(),
        "chunk_count": len(chunks)
    }

    doc_chunks = load_doc_chunks()
    for idx, chunk in enumerate(chunks):
        emb = embed_text(chunk)
        doc_chunks.append({
            "id":          str(uuid.uuid4()),
            "document_id": file_id,
            "filename":    original_name,
            "text":        chunk,
            "embedding":   emb,
            "chunk_index": idx,
            "is_code":     is_code_file(original_name)
        })

    documents = load_documents()
    documents.append(doc_meta)
    save_documents(documents)
    save_doc_chunks(doc_chunks)
    return doc_meta


def delete_document(file_id: str) -> bool:
    documents  = load_documents()
    doc_chunks = load_doc_chunks()
    target = next((d for d in documents if d["id"] == file_id), None)
    if not target:
        return False
    stored = target.get("stored_name")
    if stored:
        p = UPLOADS_DIR / stored
        if p.exists():
            try:
                p.unlink()
            except Exception:
                pass
    save_documents([d for d in documents if d["id"] != file_id])
    save_doc_chunks([c for c in doc_chunks if c.get("document_id") != file_id])
    return True


# ── Retrieval ─────────────────────────────────────────────────────────────────

def retrieve_docs(query_emb: List[float]) -> List[Dict]:
    return top_k_similar(query_emb, load_doc_chunks(), TOP_K_DOCS)


# ── Code Intent Detection ─────────────────────────────────────────────────────

CODE_PATTERNS = [
    r"```[\s\S]*?```", r"\bdef\s+\w+\(", r"\bclass\s+\w+", r"\bimport\s+\w+",
    r"\bfunction\s+\w+\(", r"\bconst\s+\w+\s*=", r"\bSELECT\b.+\bFROM\b",
]
CODE_PHRASES = [
    "write code", "generate code", "fix this code", "debug", "refactor",
    "implement", "build a function", "create a script", "give me code",
]


def detect_code_intent(prompt: str, doc_hits: List[Dict]) -> bool:
    lowered = prompt.lower()
    score   = 0
    for p in CODE_PATTERNS:
        if re.search(p, prompt, re.IGNORECASE | re.MULTILINE):
            score += 2
            break
    for phrase in CODE_PHRASES:
        if phrase in lowered:
            score += 2
    if sum(1 for d in doc_hits if d.get("is_code")) >= 2:
        score += 1
    return score >= 2


# ── Message Builder ───────────────────────────────────────────────────────────

def build_messages(prompt: str, doc_hits: List[Dict]) -> List[Dict]:
    system = (
        "You are Gyan Yantra (Knowledge Instrument), a voice-first AI assistant. "
        "Respond in clear, natural spoken English. "
        "Do NOT use markdown, bullet points, numbered lists, asterisks, or any formatting symbols. "
        "Speak as if you are talking to the user directly. "
        "Keep responses concise and conversational. "
        "Never say 'As an AI' or similar phrases."
    )
    messages = [{"role": "system", "content": system}]

    if doc_hits:
        ctx = "\n\n".join(
            f"[From {h.get('filename', 'document')}]\n{h.get('text', '').strip()}"
            for h in doc_hits
        )
        messages.append({"role": "system", "content": f"Relevant document context:\n\n{ctx}"})

    messages.append({"role": "user", "content": prompt})
    return messages


# ── Core Voice Pipeline ───────────────────────────────────────────────────────

async def run_voice_pipeline(
    prompt: str,
    interrupt_event: asyncio.Event,
) -> AsyncGenerator[Dict, None]:
    """
    Embed → retrieve docs → stream LLM text → single TTS call.
    Yields WebSocket protocol dicts.
    """

    # 1. Embed + retrieve docs
    try:
        query_emb = await asyncio.get_event_loop().run_in_executor(None, embed_text, prompt)
        doc_hits  = await asyncio.get_event_loop().run_in_executor(None, retrieve_docs, query_emb)
    except Exception as e:
        yield {"type": "error", "message": f"Retrieval failed: {e}"}
        return

    # 2. Route model + build messages
    use_code = detect_code_intent(prompt, doc_hits)
    model    = CODE_MODEL if use_code else GENERAL_MODEL
    messages = build_messages(prompt, doc_hits)

    yield {"type": "thinking", "model": model}

    # 3. Stream LLM — text to UI token by token
    full_response = ""
    try:
        async with httpx.AsyncClient(timeout=300) as client:
            async with client.stream(
                "POST",
                CHAT_ENDPOINT,
                json={"model": model, "messages": messages, "stream": True}
            ) as response:
                response.raise_for_status()
                async for raw_line in response.aiter_lines():
                    if interrupt_event.is_set():
                        return
                    if not raw_line:
                        continue
                    try:
                        chunk = json.loads(raw_line)
                    except Exception:
                        continue
                    if "error" in chunk:
                        yield {"type": "error", "message": chunk["error"]}
                        return
                    token = chunk.get("message", {}).get("content", "")
                    if token:
                        full_response += token
                        yield {"type": "text_chunk", "content": token}
                    if chunk.get("done"):
                        break
    except Exception as e:
        yield {"type": "error", "message": f"LLM failed: {e}"}
        return

    # 4. Single TTS call over full response
    if full_response.strip() and not interrupt_event.is_set():
        try:
            audio_bytes = await asyncio.get_event_loop().run_in_executor(
                None, synthesize_speech, full_response.strip()
            )
            if audio_bytes and not interrupt_event.is_set():
                yield {
                    "type": "audio_chunk",
                    "data": base64.b64encode(audio_bytes).decode("utf-8"),
                    "text": full_response.strip()
                }
        except Exception as e:
            yield {"type": "error", "message": f"TTS failed: {e}"}

    yield {"type": "done"}


# ── Ollama Health ─────────────────────────────────────────────────────────────

def check_ollama() -> tuple[bool, Optional[str]]:
    try:
        httpx.get(OLLAMA_HOST, timeout=2)
        return True, None
    except httpx.ConnectError:
        return False, "Ollama is not running. Start it with: ollama serve"
    except Exception as e:
        return False, str(e)
