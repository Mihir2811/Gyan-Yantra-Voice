import os
import json
import base64
import asyncio
import tempfile
import shutil
from pathlib import Path
from typing import Dict

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, UploadFile, File, Form
from starlette.requests import Request
from fastapi.responses import HTMLResponse, JSONResponse

import app as backend

# ── App Setup ─────────────────────────────────────────────────────────────────

fastapi_app   = FastAPI(title="Gyan Yantra Voice")
TEMPLATES_DIR = Path(__file__).parent / "templates"

SUPPORTED_EXTENSIONS = (
    backend.SUPPORTED_TEXT_EXTENSIONS | backend.SUPPORTED_PDF_EXTENSIONS
)

# Maps websocket connection → interrupt event
active_sessions: Dict[str, asyncio.Event] = {}


# ── Routes ────────────────────────────────────────────────────────────────────

@fastapi_app.get("/", response_class=HTMLResponse)
async def root():
    html = (TEMPLATES_DIR / "index.html").read_text(encoding="utf-8")
    return HTMLResponse(content=html)


@fastapi_app.get("/health")
async def health():
    ok, err = backend.check_ollama()
    if ok:
        return {"status": "ok"}
    return JSONResponse({"status": "error", "message": err}, status_code=503)


@fastapi_app.get("/files")
async def list_files():
    return {"files": backend.load_documents()}


@fastapi_app.post("/upload")
async def upload_file(file: UploadFile = File(...)):
    ok, err = backend.check_ollama()
    if not ok:
        return JSONResponse({"error": err}, status_code=503)

    original_name = file.filename or "upload"
    ext = Path(original_name).suffix.lower()

    if ext not in SUPPORTED_EXTENSIONS:
        return JSONResponse({"error": f"Unsupported file type: {ext}"}, status_code=400)

    if ext in backend.SUPPORTED_PDF_EXTENSIONS and not backend.PDF_AVAILABLE:
        return JSONResponse({"error": "pypdf not installed."}, status_code=400)

    with tempfile.NamedTemporaryFile(suffix=ext, delete=False) as tmp:
        tmp_path = Path(tmp.name)
        shutil.copyfileobj(file.file, tmp)

    try:
        doc_meta = await asyncio.get_event_loop().run_in_executor(
            None, backend.ingest_file, tmp_path, original_name
        )
        return {"message": "Uploaded and indexed.", "file": doc_meta}
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=500)
    finally:
        try:
            tmp_path.unlink()
        except Exception:
            pass


@fastapi_app.delete("/files/{file_id}")
async def delete_file(file_id: str):
    ok = backend.delete_document(file_id)
    if not ok:
        return JSONResponse({"error": "File not found."}, status_code=404)
    return {"message": "Deleted."}


# ── WebSocket ─────────────────────────────────────────────────────────────────

@fastapi_app.websocket("/ws/{conn_id}")
async def websocket_endpoint(websocket: WebSocket, conn_id: str):
    await websocket.accept()

    interrupt_event = asyncio.Event()
    active_sessions[conn_id] = interrupt_event
    pipeline_task = None

    async def send(data: dict):
        try:
            await websocket.send_text(json.dumps(data))
        except Exception:
            pass

    try:
        while True:
            raw = await websocket.receive_text()

            try:
                msg = json.loads(raw)
            except Exception:
                continue

            msg_type = msg.get("type")

            # ── Interrupt ──────────────────────────────────────────────────
            if msg_type == "interrupt":
                interrupt_event.set()
                if pipeline_task and not pipeline_task.done():
                    pipeline_task.cancel()
                    try:
                        await pipeline_task
                    except (asyncio.CancelledError, Exception):
                        pass
                interrupt_event = asyncio.Event()
                active_sessions[conn_id] = interrupt_event
                pipeline_task = None
                await send({"type": "interrupted"})
                continue

            # ── Audio ──────────────────────────────────────────────────────
            if msg_type == "audio":
                audio_b64 = msg.get("data", "")
                if not audio_b64:
                    continue

                try:
                    audio_bytes = base64.b64decode(audio_b64)
                except Exception:
                    await send({"type": "error", "message": "Invalid audio data."})
                    continue

                # Cancel any running pipeline
                interrupt_event.set()
                if pipeline_task and not pipeline_task.done():
                    pipeline_task.cancel()
                    try:
                        await pipeline_task
                    except (asyncio.CancelledError, Exception):
                        pass

                interrupt_event = asyncio.Event()
                active_sessions[conn_id] = interrupt_event

                # Transcribe
                mime = msg.get("mime", "audio/webm")
                await send({"type": "transcribing"})
                try:
                    transcript = await asyncio.get_event_loop().run_in_executor(
                        None, backend.transcribe_audio, audio_bytes, mime
                    )
                except Exception as e:
                    await send({"type": "error", "message": f"Transcription failed: {e}"})
                    continue

                if not transcript.strip():
                    await send({"type": "error", "message": "Could not understand audio. Please try again."})
                    continue

                await send({"type": "transcription", "text": transcript})

                # Run pipeline as background task
                current_interrupt = interrupt_event

                async def run_pipeline(prompt: str, ev: asyncio.Event):
                    async for event in backend.run_voice_pipeline(prompt, ev):
                        await send(event)

                pipeline_task = asyncio.create_task(
                    run_pipeline(transcript, current_interrupt)
                )
                continue

            # ── Ping ───────────────────────────────────────────────────────
            if msg_type == "ping":
                await send({"type": "pong"})
                continue

    except WebSocketDisconnect:
        pass
    except Exception:
        pass
    finally:
        interrupt_event.set()
        if pipeline_task and not pipeline_task.done():
            pipeline_task.cancel()
        active_sessions.pop(conn_id, None)


# ── Entry Point ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:fastapi_app", host="127.0.0.1", port=8000, reload=False)
